export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBvYA5Kw_ISaWFo0pz6nUPj2zfZjdv1udk",
    authDomain: "furniture-shopping-0311.firebaseapp.com",
    databaseURL: "https://furniture-shopping-0311.firebaseio.com",
    projectId: "furniture-shopping-0311",
    storageBucket: "furniture-shopping-0311.appspot.com",
    messagingSenderId: "817133444128"
  }
};
