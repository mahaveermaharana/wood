import { Product } from './product';
export interface ShoppingCartProduct {
    product?: Product;
    quantity: number;
}
